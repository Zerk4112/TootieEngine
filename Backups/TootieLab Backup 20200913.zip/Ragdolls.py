import pygame
import pymunk

class Dummy:
    def __init__(self, space, pos):
        self.space = space
        self.width, self.height = 30, 60
        self.vertices = [(-self.width / 2, -self.height / 2), (self.width / 2, -self.height / 2),
                         (self.width / 2, self.height / 2), (-self.width / 2, self.height / 2)]
        # self.body = pymunk.Body(5, pymunk.inf)  # Create a body for the player.
        self.headOffset = (0, 40)
        self.neckOffset = (0, 30)
        self.bodyOffset = (0, 0)

        # Head - Physical Object Information

        self.head_body = pymunk.Body(10, 300, body_type=pymunk.Body.DYNAMIC)
        self.head_body.position = (pos[0] - self.headOffset[0], pos[1] - self.headOffset[1])  # Set position to given position + box_offset
        self.head_shape = pymunk.Circle(self.head_body, 15)
        self.head_shape.friction = 0.99


        # Upper Torso - Physical Object Information
        self.upperTorso_body = pymunk.Body(10, 300, body_type=pymunk.Body.DYNAMIC)
        self.upperTorso_body.position = (pos[0] - self.bodyOffset[0], pos[1] - self.bodyOffset[1])  # Set position to given position + box_offset
        self.upperTorso_shape = pymunk.Poly(self.upperTorso_body, self.vertices)
        self.upperTorso_shape.friction = 0.99

        self.neckConstraint = pymunk.SlideJoint(self.head_body, self.upperTorso_body, (0, 10), (self.neckOffset[0], -self.neckOffset[1]), 2, 8)

        self.lowerTorso_body = pymunk.Body(10, 10, body_type=pymunk.Body.KINEMATIC)
        self.lowerTorso_shape = pymunk.Poly(self.lowerTorso_body, self.vertices)


        self.leftArm_body = pymunk.Body(10, 10, body_type=pymunk.Body.KINEMATIC)
        self.rightArm_body = pymunk.Body(10, 10, body_type=pymunk.Body.KINEMATIC)

        self.leftArm_shape = pymunk.Poly(self.upperTorso_body, self.vertices)
        self.rightArm_shape = pymunk.Poly(self.lowerTorso_body, self.vertices)

        self.leftLeg_body = pymunk.Body(10, 10, body_type=pymunk.Body.KINEMATIC)
        self.rightLeg_body = pymunk.Body(10, 10, body_type=pymunk.Body.KINEMATIC)

        self.leftLeg_shape = pymunk.Poly(self.upperTorso_body, self.vertices)
        self.rightLeg_shape = pymunk.Poly(self.lowerTorso_body, self.vertices)



    def addToSpace(self):
        # Add Head
        self.space.add(self.head_body, self.head_shape)
        self.space.add(self.upperTorso_body, self.upperTorso_shape)
        self.space.add(self.neckConstraint)

